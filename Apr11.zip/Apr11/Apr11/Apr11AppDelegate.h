//
//  Apr11AppDelegate.h
//  Apr11
//
//  Created by Joe Gabela on 4/13/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface Apr11AppDelegate : UIResponder <UIApplicationDelegate>
{
	UIWindow *_window;
}

@property (strong, nonatomic) UIWindow *window;

@end
