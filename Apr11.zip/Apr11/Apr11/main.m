//
//  main.m
//  Apr11
//
//  Created by Joe Gabela on 4/13/13.
//  Copyright (c) 2013 Joe Gabela. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "Apr11AppDelegate.h"

int main(int argc, char *argv[])
{
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([Apr11AppDelegate class]));
    }
}
